--
-- note: this script assumes pg_hba.conf is configured correctly
--


begin;

INSERT INTO DATASOURCE VALUES('SampleData',20,'org.postgresql.Driver',5,'pentaho_user','cGFzc3dvcmQ=','jdbc:postgresql://localhost:5432/sampledata','select 1',1000);

commit;
